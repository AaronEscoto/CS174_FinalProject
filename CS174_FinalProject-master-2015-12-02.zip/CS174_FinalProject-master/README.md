# CS174_FinalProject

A perfect day application that plans your day for you!

Under construction... 
